/*
 * crossing_functions.h
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */

#ifndef INC_CROSSING_FUNCTIONS_H_
#define INC_CROSSING_FUNCTIONS_H_

void Led_on(uint8_t Lednr);
void Led_off(uint8_t Lednr);
bool PL2_hit(void);
uint32_t Get_timer_time();
void Walk_across_time(uint32_t walkingDelay);

extern uint32_t trafficLightState;

#endif /* INC_CROSSING_FUNCTIONS_H_ */
