/*
 * test.h
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

void Test_program(void);
void Test_LEDs(void);
void Test_Turn_off_LEDs(void);
void Test_buttons(void);
void Test_blue_toggle(void);
void Test_traffic_transition(void);
void Test_timer(void);

#endif /* INC_TEST_H_ */
