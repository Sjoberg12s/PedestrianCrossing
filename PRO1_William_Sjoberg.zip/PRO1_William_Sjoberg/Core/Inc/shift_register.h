/*
 * shift_register.h
 *
 *  Created on: Dec 9, 2024
 *      Author: William Sjöberg
 */

#ifndef INC_SHIFT_REGISTER_H_
#define INC_SHIFT_REGISTER_H_

void Set_state(uint32_t data);
void Latch_shift_data(void);
void Reset_shift_data(void);

#endif /* INC_SHIFT_REGISTER_H_ */
