/*
 * crossing.h
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */

#ifndef INC_CROSSING_H_
#define INC_CROSSING_H_

void Crossing(void);

#endif /* INC_CROSSING_H_ */
