/*
 * crossing.c
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */
#include "stdbool.h"
#include "gpio.h"
#include "crossing_functions.h"

typedef enum
{ CarsPassing,
PedestrianWait,
PedestrianPassing,
} states;
static states State;

//Variables for crossing
uint32_t toggleFreq = 300; //toggle frequency in ms
uint32_t pedestrianDelay = 5000; //delay in ms
uint32_t walkingDelay = 5000; //delay in ms
uint32_t orangeDelay = 5000; //delay in ms

//Traffic light states
bool blueLedOn = false;
uint32_t latestToggleTime = 0;

uint32_t latestOrangeTime = 0;
bool orangeOn = false;
bool redOn = false;
bool isEntryTimeSet = false;
bool pedestrianDelayOn = false;
uint32_t latestPedestrianTime = 0;
uint32_t entryTime = 0;

//Pedestrian states for the state machine.
bool pedestrianButton = false; //button for pedestrian to click if they want to walk across
bool pedestrianCanCross = false; //Shows when a pedestrian can walk across

void Crossing(void)
{
	//Initialized state
	Led_on(12);
	Led_on(6);
	Led_on(19);//Turns on 20 as well.

	State = CarsPassing;
	while(1)
	{
		switch (State)
		{
		case CarsPassing:
			if(PL2_hit() == true)//Checks if pedestrian signal is pressed
			{
				State = PedestrianWait; //Switches to PedestrianWait state.
			}
			break;
		case PedestrianWait:
			if(Get_timer_time() - latestToggleTime >= toggleFreq) //Goes in if toggleFreq time has passed.
			{
				if(blueLedOn != true) //Goes in if Blue LED is off
				{
					Led_on(23); //Turns on blue LED
					blueLedOn = true;
					latestToggleTime = Get_timer_time(); //Sets the latest toggle time to the current timer time.
				}
				else //Blue Led is on
				{
					Led_off(23); //Turns off blue LED
					blueLedOn = false;
					latestToggleTime = Get_timer_time(); //Sets the latest toggle time to the current timer time.
				}
			}
			if (!isEntryTimeSet) //Goes in if a entry time has not been set
			{
				entryTime = Get_timer_time(); //Sets a entry time from the current timer time.
				isEntryTimeSet = true;
			}
			if (Get_timer_time() - entryTime >= 5000) //Goes in if 5000 milliseconds have passed since entryTime
			{
				if (orangeOn != true && redOn != true ) //Goes in if orange and red LEDs are off
				{
					//Turns off green LEDs
					Led_off(12);
					Led_off(6);
					//Turns on orange LEDs
					Led_on(11);
					Led_on(5);

					latestOrangeTime = Get_timer_time(); //Sets a latest orange time from the current timer time.
					orangeOn = true;
				}
			}
			//Goes in if the orangeDelay time has passed and if the orange LEDs are on.
			if ((Get_timer_time() - latestOrangeTime >= orangeDelay) && orangeOn == true)
			{
				//Turns off orange LEDs
				Led_off(11);
				Led_off(5);
				//Turns on red LEDs
				Led_on(10);
				Led_on(4);

				latestPedestrianTime = Get_timer_time(); //Sets a entry time for the pedestrian delay variable.
				pedestrianDelayOn = true;
				orangeOn = false;
				redOn = true;
			}
			//Goes in if pedestrianDelay time has passed and if pedestrianDelayOn is true.
			if ((Get_timer_time() - latestPedestrianTime >= pedestrianDelay) && pedestrianDelayOn == true)
			{
				State = PedestrianPassing; //Switches to PedestrianPassing state.
				pedestrianCanCross = true;
			}
			break;
		case PedestrianPassing:
			if (pedestrianCanCross == true)
			{
				//Switches the red pedestrian light to green.
				Led_off(19);
				Led_on(21);
				Walk_across_time(walkingDelay); //Delays for walkingDelay milliseconds.
				//Switches the green pedestrian light to red.
				Led_off(21);
				Led_on(19);
				pedestrianCanCross = false;

			}
			//Goes in if orange LEDs are off and red LEDs are on.
			if (orangeOn != true && redOn == true )
			{
				//Turns off red LEDs
				Led_off(10);
				Led_off(4);
				//Turns on orange LEDs
				Led_on(11);
				Led_on(5);
				latestOrangeTime = Get_timer_time(); //Sets a latestOrangeTime from the current timer time.
				orangeOn = true;
				redOn = false;
			}
			//Goes in if orangeDelay time has passed and if orange LEDs are on.
			if ((Get_timer_time() - latestOrangeTime >= orangeDelay) && orangeOn == true)
			{
				//Turns off orange LEDs
				Led_off(11);
				Led_off(5);
				//Turns on green LEDs
				Led_on(12);
				Led_on(6);
				orangeOn = false;

				//RESET ALL VARIABLES FOR NEXT CAR PASSING
				latestOrangeTime = 0;
				latestPedestrianTime = 0;
				latestToggleTime = 0;
				isEntryTimeSet = false;
				pedestrianDelayOn = false;

				State = CarsPassing;
			}
			break;
		default:
			break;
		}
	}
} //End of function Crossing
