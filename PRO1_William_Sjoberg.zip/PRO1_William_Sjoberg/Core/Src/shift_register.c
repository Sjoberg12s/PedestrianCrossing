/*
 * shift_register.c
 *
 *  Created on: Dec 9, 2024
 *      Author: William Sjöberg
 */

#include "stdbool.h"
#include "gpio.h"
#include "shift_register.h"

void Set_state(uint32_t data){
	Reset_shift_data();

	int i = 0;
	uint8_t bit = 0;
	for(i = 0; i < 22; i++){
	   bit = (data >> i) & 0x00000001; //Copy the rightmost bit.
	   HAL_GPIO_WritePin(DS_595_GPIO_Port, DS_595_Pin, bit);
	   HAL_GPIO_WritePin(SHCP_595_GPIO_Port, SHCP_595_Pin, GPIO_PIN_SET);
	   HAL_GPIO_WritePin(SHCP_595_GPIO_Port, SHCP_595_Pin, GPIO_PIN_RESET);
	}
}

void Reset_shift_data(void){
	// Reset the shift register
	HAL_GPIO_WritePin(Reset_595_GPIO_Port, Reset_595_Pin, GPIO_PIN_RESET);
	HAL_Delay(1); // Small delay, ensures correct functionality.
	HAL_GPIO_WritePin(Reset_595_GPIO_Port, Reset_595_Pin, GPIO_PIN_SET);
}

void Latch_shift_data(void){
	// Latch data
	HAL_GPIO_WritePin(STCP_595_GPIO_Port, STCP_595_Pin, GPIO_PIN_SET);
	HAL_Delay(1); // Small delay, ensures correct functionality.
	HAL_GPIO_WritePin(STCP_595_GPIO_Port, STCP_595_Pin, GPIO_PIN_RESET);
}
