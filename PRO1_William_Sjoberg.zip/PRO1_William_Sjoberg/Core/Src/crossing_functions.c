/*
 * crossing_functions.c
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */
#include "stdbool.h"
#include "gpio.h"
#include "usart.h"
#include "crossing_functions.h"
#include "shift_register.h"

//uint32_t trafficLightState = 0x00000C01; //Initial state
uint32_t trafficLightState = 0x00000000; //No lights are on.

/**
@brief PL2_hit, checks if pedestrian button is pressed

@param void

@return bool, true if hit and false if not hit
*/
bool PL2_hit(void)//Returns true if the button is pressed.
{ if (HAL_GPIO_ReadPin(PL2_Button_GPIO_Port, PL2_Button_Pin) == 0) return true;
 else return false;
}

/**
@brief Led_on, turns on one of the LEDs on the pedestrian or traffic crossing

@param uint8_t Lednr, number of the LED that is going to be turned on

@return void
*/
void Led_on(uint8_t Lednr)
{
	switch(Lednr){
	case 6 ://Green led, Street direction 4.
		if((trafficLightState & 0x00000800) != 0x00000800) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000800;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 5 ://Orange led, Street direction 4.
		if((trafficLightState & 0x00001000) != 0x00001000) //Checks if it is not on.
		{
			trafficLightState ^= 0x00001000;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 4 ://Red led, Street direction 4.
		if((trafficLightState & 0x00002000) != 0x00002000) //Checks if it is not on.
		{
			trafficLightState ^= 0x00002000;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 10 ://Red led, Street direction 2.
		if((trafficLightState & 0x00000004) != 0x00000004) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000004;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 11 ://Orange led, Street direction 2.
		if((trafficLightState & 0x00000002) != 0x00000002) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000002;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 12 ://Green led, Street direction 2.
		if((trafficLightState & 0x00000001) != 0x00000001) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000001;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 19 ://Red led, Pedestrian crossing.
	case 20 ://Red led, Pedestrian crossing.
		if((trafficLightState & 0x00000400) != 0x00000400) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000400;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 21 ://Green led, Pedestrian crossing.
	case 22 ://Green led, Pedestrian crossing.
		if((trafficLightState & 0x00000200) != 0x00000200) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000200;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 23 ://Blue led, Pedestrian crossing.
	case 24 ://Blue led, Pedestrian crossing.
		if((trafficLightState & 0x00000100) != 0x00000100) //Checks if it is not on.
		{
			trafficLightState ^= 0x00000100;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;

	}
}

/**
@brief Led_off, turns off one of the LEDs on the pedestrian or traffic crossing

@param uint8_t Lednr, number of the LED that is going to be turned off

@return void
*/
void Led_off(uint8_t Lednr)
{
	switch(Lednr){
	case 6 ://Green led, Street direction 4.
		if((trafficLightState & 0x00000800) == 0x00000800) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000800;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 5 ://Orange led, Street direction 4.
		if((trafficLightState & 0x00001000) == 0x00001000) //Checks if it already is on.
		{
			trafficLightState ^= 0x00001000;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 4 ://Red led, Street direction 4.
		if((trafficLightState & 0x00002000) == 0x00002000) //Checks if it already is on.
		{
			trafficLightState ^= 0x00002000;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 10 ://Red led, Street direction 2.
		if((trafficLightState & 0x00000004) == 0x00000004) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000004;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 11 ://Orange led, Street direction 2.
		if((trafficLightState & 0x00000002) == 0x00000002) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000002;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 12 ://Green led, Street direction 2.
		if((trafficLightState & 0x00000001) == 0x00000001) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000001;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 19 ://Red led, Pedestrian crossing.
	case 20 ://Red led, Pedestrian crossing.
		if((trafficLightState & 0x00000400) == 0x00000400) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000400;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 21 ://Green led, Pedestrian crossing.
	case 22 ://Green led, Pedestrian crossing.
		if((trafficLightState & 0x00000200) == 0x00000200) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000200;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;
	case 23 ://Blue led, Pedestrian crossing.
	case 24 ://Blue led, Pedestrian crossing.
		if((trafficLightState & 0x00000100) == 0x00000100) //Checks if it already is on.
		{
			trafficLightState ^= 0x00000100;
			Set_state(trafficLightState);
			Latch_shift_data();
		}
		break;

	}
}

/**
@brief Get_timer_time, gets the current timer time on the microcontroller

@param void

@return HAL_GetTick(), the current timer time in milliseconds
*/
uint32_t Get_timer_time() //Returns the timer time at the moment.
{
	return HAL_GetTick();
}

/**
@brief Walk_across_time, simulates a delay for the pedestrians to walk across

@param uint32_t walkingDelay, variable in milliseconds that dictates how long the delay is

@return void
*/
void Walk_across_time(uint32_t walkingDelay)//Simulates a delay for walkingDelay ms.
{
	HAL_Delay(walkingDelay);
}

