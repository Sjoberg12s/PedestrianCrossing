/*
 * test.c
 *
 *  Created on: Dec 2, 2024
 *      Author: William Sjöberg
 */

#include "stdbool.h"
#include "gpio.h"
#include "test.h"
#include "crossing_functions.h"
#include "shift_register.h"

void Test_program(void)
{
	/*Resets the shift register*/
	Reset_shift_data();
	Latch_shift_data();

    //Test_LEDs();
    //Test_Turn_off_LEDs();
    //Test_init_state();
    //Test_buttons();
    //Test_blue_toggle();
	//Test_traffic_transition();
	Test_timer();

} //End of function


void Test_buttons(void)
{
	int8_t j = 0;
    while(j == 0)
    {
    	if(PL2_hit() == true){
    		Test_blue_toggle(); //Calls the blue toggle when pressed.
    	}
    }
}

void Test_LEDs(void)
{
	Reset_shift_data();

    // Send data
    int i = 0;
    for(i = 4; i < 7; i++){
    	Led_on(i);
    	HAL_Delay(2000);
    }
    for(i = 10; i < 13; i++){
    	Led_on(i);
    	HAL_Delay(2000);
    }
    Led_on(19);
    HAL_Delay(2000);
    Led_on(21);
    HAL_Delay(2000);
    Led_on(23);
}

void Test_Turn_off_LEDs(void)
{
	Test_LEDs(); //First, Turn on LEDs
	int i = 0;
    //HAL_Delay(4000); //wait a bit

    //Second, turn off LEDs
    for(i = 4; i < 7; i++){
    	Led_off(i);
    	HAL_Delay(2000);
    }
    for(i = 10; i < 13; i++){
    	Led_off(i);
    	HAL_Delay(2000);
    }
    Led_off(19);
    HAL_Delay(2000);
    Led_off(21);
    HAL_Delay(2000);
    Led_off(23);
}

void Test_traffic_transition(void){
	//Green
	Led_on(6);
	Led_on(12);
	HAL_Delay(3000);
	Led_off(6);
	Led_off(12);
	//Orange
	Led_on(5);
	Led_on(11);
	HAL_Delay(3000);
	Led_off(5);
	Led_off(11);
	//Red
	Led_on(4);
	Led_on(10);
}

void Test_blue_toggle(void)
{
	bool blueOn = false;
	while(1)
	{
		if (blueOn != true){
			Led_on(23);
			blueOn = true;
		}
		else
		{
			Led_off(23);
			blueOn = false;
		}
		HAL_Delay(1000);
	}
}

void Test_timer(void)
{
	bool start = false;
	bool ledOn = false;
	uint32_t freq = 2000;
	uint32_t entryTime = 0;
	while(1)
	{
		if(start != true)
		{
			entryTime = Get_timer_time();
			start = true;
		}
		if(Get_timer_time() - entryTime >= freq){
			if(ledOn != true)
			{
				Led_on(23);
				ledOn = true;
			}
			else{
				Led_off(23);
				ledOn = false;
			}
			start = false;
		}
	}
}

